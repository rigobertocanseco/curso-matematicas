#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from pivy.gui.soqt import *
from pivy.coin import *
from PyQt4 import QtGui, QtCore, uic
from modulos.util import main
from math import sqrt, cos, sin, asin, pi, pow
from MallaBase2 import MallaBase,  ParametricPlot3D,  creaVars, creaVarParam
from Visor import Visor


class Regladas(object):
    name = "Superficies Regladas"
    def __init__(self,parent=None,controles=None):
#        Visor.__init__(self,parent,controles)
        self.parent = parent
        x, y, z, u, v,  cose, sen, t = creaVars(['x', 'y', 'z', 'u', 'v','cos', 'sen', 't'])
        ## ============================
        hiperboloide = ParametricPlot3D(
            lambda w, u, t: ((1 - t)* cos(u) + t *cos(u + w*pi), (1 - t) *sin(u) + t *sin(u + w*pi), -1 + 2* t),
            ('u', -pi, pi), (0, 1), addXdelta=.025, extraParms=[(("w",0,1),0.8)], name = "Hiperboloide de<br>un manto")
        hiperboloide.addEqn(x**2+y**2 - z**2==1)
        hiperboloide.text = u"Para un <b>hiperboloide de un manto</b>, las reglas son transversales (no perpendiculares) al plano de una circunferencia y recorren la circunferencia formando siempre el mismo ángulo con el radio en cuyo extremo se apoyan. Curiosamente, las rectas simétricas respecto a los planos que contienen a los radios y al eje del hiperboloide también están contenidas en el hiperboloide, por eso es una <b>superficie doblemente reglada</b>."
        ## ============================
        paraboloide = ParametricPlot3D(lambda x, y: (x, y, x*y), (-1, 1), (-1, 1), addYdelta=.025, name = u"Paraboloide hiperbólico")
        paraboloide.addEqn(z == x*y)
        paraboloide.text = u"Un <b>paraboloide hiperbólico</b> también es una superficie doblemente reglada. En este caso, las reglas recorren una recta fija, por ejemplo el eje X, siempre en un plano perpendicular al eje X de forma que en el punto (t, 0, 0) su dirección esté dada por el vector (0, 1, t). Como en el caso anterior, en cada punto de una regla hay otra regla contenida en el paraboloide hiperbólico."
        ## ============================
        cilindroEliptico = ParametricPlot3D(lambda u, z: (cos(u),sin(u),z),
            ('u', -pi, pi), (-2, 2), addXdelta=.025, name = u"Cilindro Elíptico")
        ## JP
        #~ cilindroEliptico.addEqn(y == sen(u))
        #~ cilindroEliptico.addEqn(x == cose(u))
        ## Ana
        cilindroEliptico.addEqn(x**2 + 2 * y**2 == 1)
        cilindroEliptico.text = u"Si las reglas se conservan paralelas entre sí mientras recorren una elipse en un plano transversal a ellas, resulta un <b>cilindro elíptico</b>."
        ## ============================
        moebius = ParametricPlot3D(
            lambda u, v: (cos(u) + v*cos(u/2)*cos(u), sin(u) + v*cos(u/2)*sin(u), v*sin(u/2)),
            ('u', -pi, pi, 60), (-.5, .5, 14), addXdelta=.025, name = u"Banda de Möbius")
        moebius.addEqn(z == v*'sen <em>u</em>/2')
        moebius.addEqn(y == 'sen <em>u</em> ' + v*'cos <em>u</em>/2'*'sen <em>u</em>')
        moebius.addEqn(x == 'cos <em>u</em> ' + v*'cos <em>u</em>/2'*'cos <em>u</em>')
        moebius.text = u"Una <b>Banda de Möbius</b> resulta de mover no una recta completa, sino sólo un segmento cuyo punto central recorre una circunferencia; el segmento se inclina la mitad del ángulo que ha girado su punto central, y por ello al completar el recorrido el segmento llega “de cabeza” dando lugar a una superficie con sólo un lado."
        ## ============================
        helicoide = ParametricPlot3D(lambda u, v: (v * cos(u), v * sin(u), u), ('u', 0, 2*pi, 100), (-pi, pi, 15), addXdelta=.025, name = "Helicoide")
        helicoide.addEqn(z == u)
        helicoide.addEqn(y == v*sen(u))
        helicoide.addEqn(x == v*cose(u))
        helicoide.text = u"Las rampas de los estacionamientos de automóviles son parte de una <b>helicoide</b>. Aquí las reglas recorren una hélice inscrita en un cilindro de forma que siempre son perpendiculares al eje del cilindro."
        ## ============================
        conoide = ParametricPlot3D(lambda u, t: (t*cos(u), t* sin(u), cos(u)*sin(u)), ('u',  0, 2*pi, 115), (0.1, 1, 15), addXdelta=.025,name = "Conoide" )
        conoide.addEqn(z == cose(u)*sen(u))
        conoide.addEqn(y == t*sen(u) )
        conoide.addEqn(x == t*cose(u))
        conoide.text = u"La <b>conoide</b> resulta cuando las reglas recorren una senoide inscrita en un cilindro y son todas perpendiculares al eje del cilindro."
        ## ============================
        self.obs = [
            hiperboloide,
            paraboloide,
            cilindroEliptico,
            moebius,
            helicoide,
            conoide
        ]

    def getPages(self):
        return self.obs

    def getProlog(self):
        grp = SoGroup()
        env = SoEnvironment()
        env.ambientIntensity = .2
        grp.addChild(env)
        return grp

    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_ALL
        self.parent.lucesBlanca.on = False
        self.parent.viewer.setTransparencyType(SoGLRenderAction.NONE)
        self.parent.setDrawStyle(SoQtViewer.VIEW_WIREFRAME_OVERLAY)


if __name__ == "__main__":
    app = main(sys.argv)
    window = Regladas()
    window.resize(400, 400)
    window.show()
    window.ui.show()
    SoQt.mainLoop()
