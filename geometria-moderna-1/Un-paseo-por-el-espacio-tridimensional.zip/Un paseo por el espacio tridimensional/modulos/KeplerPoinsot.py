#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from pivy.gui.soqt import SoQt,  SoQtViewer
from pivy.coin import SoGLRenderAction, SoDirectionalLight, SbVec3f, SO_SWITCH_NONE, SoComplexity, SoGLRenderAction
from PyQt4 import QtGui, QtCore, uic
from modulos.util import main, leeArchivo, pjoin
from math import sqrt, cos, sin, asin, pi, pow, cosh, tanh
from Visor import Visor
from Poliedro import Poliedro1 as Poliedro, esfera, tubo
from Simetrias3Dplanos import planosColores
from random import random

basedir = "modulos/kepler-poinsot/"

def moduloPath(name):
    return pjoin("modulos","kepler-poinsot",name)


def colorAleatorio():
    return (random(), random(), random())
def coloresAleatorios(n):
    return [colorAleatorio() for i in range(n)]

colores12 = coloresAleatorios(12)
colores20 = coloresAleatorios(20)

#colores = [
#    planosColores, 
#    coloresAleatorios(20), 
#    planosColores, 
#    planosColores
#]
#coloresInd =[
#    indice1, 
#    range(20), 
#    indice1, 
#    indice1
#]


indice1 = (
    0, 0, 0, 0, 0, 
    1, 1, 1, 1, 1, 
    2, 2, 2, 2, 2, 
    3, 3, 3, 3, 3, 
    4, 4, 4, 4, 4, 
    5, 5, 5, 5, 5, 
    6, 6, 6, 6, 6, 
    7, 7, 7, 7, 7, 
    8, 8, 8, 8, 8, 
    0, 0, 0, 0, 0, 
    1, 1, 1, 1, 1, 
    2, 2, 2, 2, 2
)

indice2 = (
    0, 0, 0, 0, 0, 
    1, 1, 1, 1, 1, 
    2, 2, 2, 2, 2, 
    3, 3, 3, 3, 3, 
    4, 4, 4, 4, 4, 
    5, 5, 5, 5, 5, 
    6, 6, 6, 6, 6, 
    7, 7, 7, 7, 7, 
    8, 8, 8, 8, 8, 
    9, 9, 9, 9, 9, 
    10, 10, 10, 10, 10, 
    11, 11, 11, 11, 11
)


colores = [
    colores12, 
    colores20, 
    colores12, 
    colores12, 
]

coloresInd =[
    indice2, 
    range(20), 
    indice2, 
    indice2, 
]

textos = [
    u"El <b>gran dodecaedro</b> se construye pegando en las aristas de cada triángulo del icosaedro, hacia dentro, las caras de una pirámide triangular. En cada uno de los vértices exteriores (12), los del icosaedro, concurren 10 triángulos y en los interiores (20), los vértices de las pirámides, concurren 3 triángulos. Hay 12 pentágonos “grandes” determinados por los 5 vértices del icosaedro original que son los otros extremos de aristas que concurren en un vértice del icosaedro.", 
    u"El <b>gran icosaedro</b> resulta si en las caras de un dodecaedro (que esta vez no queda completamente oculto) pegamos “pirámides pentagramales”. En cada vértice exterior, los 12 vértices de las pirámides, concurren 10 triángulos, y en los vértices interiores, los del dodecaedro original, concurren 12 triángulos: 6 caras de las pirámides pentagramales y 6 partes de los pentágonos del dodecaedro original no contendidas en los pentagramas base de las pirámides. Se forman 20 triángulos “grandes”, cuyos lados contienen aristas coplanares prolongadas con aristas convenientes de las pirámides.", 
    u"El <b>gran dodecaedro estrellado</b>, formado al pegar pirámides triangulares en las caras de un icosaedro (que queda oculto), también tiene pentagramas formados con aristas de varias pirámides y también en este caso hay 12 pentagramas. En cada vértice exterior concurren 3 caras: los lados de las pirámides, y en cada vértice interior concurren 10 de esas caras.", 
    u"El <b>pequeño dodecaedro estrellado</b> puede verse como resultado de pegar pirámides pentagonales congruentes en cada cara de un dodecaedro (que queda oculto). Una de esas pirámides esta “rodeada” de otras 5 pirámides; los cinco triángulos pegados a los lados de una cara pentagonal del dodecaedro oculto forman los picos del pentagrama cuya parte central es la cara pentagonal, oculta, del dodecaedro original. Hay 12 de esos pentagramas. En cada uno de los vértices exteriores concurren 5 triángulos, y en cada uno de los vértices interiores concurren 6.", 
]

class KeplerPoinsot(object):
    name = u"Sólidos de Kepler-Poinsot"
    def __init__(self,parent=None,uilayout=None):
        self.parent = parent
        self.objectos = []
        archivos = [
            ("great_dodecahedron", "Gran Dodecaedro", 12, 30, 12, moduloPath("pentagono.svg")), 
            ("great_icosahedron", "Gran Icosaedro", 20, 30, 12, moduloPath("triangulo.svg")),
            ("great_stellated_dodecahedron", u"Gran Dodecaedro<br>Estrellado", 12, 30, 20, moduloPath("pentagrama.svg")), 
            ("small_stellated_dodecahedron", u"Pequeño Dodecaedro<br>Estrellado", 12, 30, 12, moduloPath("pentagrama.svg"))
        ]
        for i, a in enumerate(archivos):
            f, n = a[:2]
            datos = a[2:]
            ob = Poliedro(leeArchivo(moduloPath("%s.iv" % f)), 
                nombre=n, vertices=False, aristas=False, transparencia=False, datos=datos, colores=colores[i], coloresInd=coloresInd[i])
            ob.panel.plano.setText("<h2>cara</h2>")
            ob.text = textos[i]
            ## ============================
            ## los vértices
            ptos = map(SbVec3f, ob.verticesP)
            lmax = max((p.length() for p in ptos))
            vert = filter(lambda p: abs(p.length() - lmax) < .1, ptos)
            for p in vert:
                ob.root.addChild(esfera(p, 2*ob.escala))
            ## ============================
            ##  las aristas
            dists = [(SbVec3f(par[0]) - SbVec3f(par[1])).length() for par in ob.aristasP]
            amax = max(dists)
            for p1, p2 in ob.aristasP:
                length = (SbVec3f(p1) - SbVec3f(p2)).length()
                if abs(length - amax) < .1:
                    ob.root.addChild(tubo(p1, p2, ob.escala, 1.0))
            ## ============================
            ob.transparency.setValue(0)
            ob.material.emissiveColor.setValue(.1, 0, .0)
            self.objectos.append(ob)
#            self.addPageChild(ob)
#        self.whichFigure = 0
#        self.insertaLuz(SoDirectionalLight())
#        ## esto funciona mejor con los poliedros:
##        self.viewer.setTransparencyType(SoGLRenderAction.BLEND)
#        self.viewer.setTransparencyType(SoGLRenderAction.SORTED_LAYERS_BLEND)
#        self.viewer.viewAll()
#        self.rotor.on = False

    def getPages(self):
        return self.objectos

    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_NONE
        self.parent.lucesBlanca.on = True
        self.parent.viewer.setTransparencyType(SoGLRenderAction.SORTED_LAYERS_BLEND)
        self.parent.setDrawStyle(SoQtViewer.VIEW_AS_IS)
        
        
if __name__ == "__main__":
    app = main()
    window = KeplerPoinsot()
    window.show()
    window.resize(500, 500)
    window.ui.show()
    SoQt.mainLoop()
