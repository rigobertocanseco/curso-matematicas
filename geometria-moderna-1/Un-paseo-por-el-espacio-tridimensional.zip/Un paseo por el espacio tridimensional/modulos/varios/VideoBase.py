#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from pivy.gui.soqt import *
from pivy.coin import *
from PyQt4 import QtGui, QtCore, uic
from functools import partial
from util import lee

class VideoBase(QtCore.QObject):
    def __init__(self,parent,file):
        QtCore.QObject.__init__(self)
        self.parent = parent
        self.primeraVez = True
        self.root = self.creaNodo(file)
        self.file = file
        self.addParamWidget()

    def finalizaInit(self):
        self.paramWlayout.addStretch()

    def addParamWidget(self):
        pstack = self.parent.ui.parametrosStack
        self.paramW = QtGui.QWidget()
        self.paramWlayout  =  QtGui.QVBoxLayout()
        self.paramW.setLayout(self.paramWlayout)
        pstack.addWidget(self.paramW)
        nombre = getattr(self,"nombre", "")
        if nombre != "":
            self.label = QtGui.QLabel("<b><h1>"+nombre+"</h1></b>")
            fondo = QtGui.QPalette(QtCore.Qt.white)
            self.label.setAutoFillBackground(True)
            self.label.setAlignment(QtCore.Qt.AlignCenter)
            self.paramWlayout.addWidget(self.label,0,QtCore.Qt.AlignTop)
            line_2 = QtGui.QFrame()
            line_2.setFrameShape(QtGui.QFrame.HLine)
            line_2.setFrameShadow(QtGui.QFrame.Sunken)
            self.paramWlayout.addWidget(line_2)
           
    def creaNodo(self,file):
        root = SoSeparator()
        cubo = SoCube()
        #movie = SoVRMLMovieTexture()
        movie = SoVRMLImageTexture()
        #movie.url = file
        root.addChild(movie)
        root.addChild(cubo)
        return root

