import sys
from pivy.gui.soqt import *
from pivy.coin import *
from PyQt4 import QtGui
from Visor import Visor
from VideoBase import VideoBase

class Videos(Visor):
    nombre = "Videos"
    def __init__(self,parent=None,controles=None):
        Visor.__init__(self,parent,controles)
        self.setDrawStyle(SoQtExaminerViewer.VIEW_AS_IS)
        # =============================
        video = VideoBase(self,"/home/jpablo/trabajo/ixtli/open-inventor/p1000257.jpg")
        self.addPageChild(video)
        
if __name__ == "__main__":
    from modulos.util import main
    app = main()
    visor = Videos()
    visor.show()
    SoQt.mainLoop()
