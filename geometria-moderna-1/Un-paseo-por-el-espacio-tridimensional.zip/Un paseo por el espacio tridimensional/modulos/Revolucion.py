#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from pivy.gui.soqt import *
from pivy.coin import *
from PyQt4 import QtGui, QtCore, uic
from modulos.util import main,  fn, partial
from math import sqrt, cos, sin, asin, pi, pow, cosh, tanh
#from functools import partial
from MallaBase2 import MallaBase, ParametricPlot3D,  creaVars, Eq, creaVarParam
from Visor import Visor

def identity(x):
    return x


class SupRevolucion(MallaBase):
    "Una superficie de revolucion general"
    def __init__(self, f, g, rangoX=(0,2*pi),  rangoY=(0, 2), name = '', eqn1=None, eqn2 = None,eqn3 = None, text=""):
        ## tiene que definirse antes de MallaBase.__init__
        self.name = name
        MallaBase.__init__(self,  rangoX,  rangoY)
        self.text = text
        self.f = f
        self.g = g
        self.addParameterX(delta = .025)
        for eq in [eqn3,eqn2,eqn1]:
            if eq != None:
                self.addEqn(eq)
        self.addQuad(lambda u, t: (self.f(t)*cos(u), self.f(t)*sin(u), self.g(t)))

x, y, z, u, c, b, sen, coseno, r = creaVars(['x', 'y', 'z','u','c', 'b', 'sen', 'cos','r'])
e , t, med, cosenoh, tanhip = creaVars(['exp', 't', '1/2', 'cosh', 'tanh'])

suprevs = [
    ## f, g, rangoX, rangoY, nombre
    (identity,  fn('#**2'), ('u',0,2*pi), (0,2),"Paraboloide", x**2 + y**2 == z, None,None,u"Una parábola que rota en torno a su eje focal forma un <b>paraboloide de revolución</b>. Una antena parabólica es parte de un paraboloide de revolución."),
    (identity,  cos, (0,2*pi, 80),  ('u',0,6*pi, 60), "Cosenoide", x == t * coseno(u), y == t * sen(u), z == "" - coseno(t), u"Si la gráfica de la curva del plano XZ: <em style='font-family:times'>z</em> = -cos(<em style='font-family:times'>x</em>)  gira en torno al eje Z resulta una superficie cuya forma recuerda las ondas formadas en el agua al caer una piedra. Llamamos a esta superficie <b>cosenoide</b>."),
    (lambda t:sin(t)+3, identity, ('u',0,2*pi),  (pi/2,6*pi+pi/2, 50),"Senoide (2)", z == t, x == sen(t)+3, None, u"Cuando la gráfica del seno gira en torno a la recta <em style='font-family:times'>x</em> = 3 resulta una superficie llamada <b>senoide</b>."),
    (lambda t:1/cosh(t),lambda t:t-tanh(t), ('u',0, 2*pi), (0,5), "Pseudoesfera", z == t - tanhip(t), x == '1/' * cosenoh(t), None, u"La huella que deja en la arena el carrito de un niño que tira de él y de pronto gira 90°, forma una curva llamada <b>tractriz</b> y que al girar en torno a su asíntota genera la superficie llamada <b>seudoesfera</b>, parecida a una trompeta y relacionada con la geometría hiperbólica.")
   ]

def toRev(f, g):
    return lambda u, t: (f(t)*cos(u), f(t)*sin(u), g(t))

class Revolucion(object):
    name = u"Superficies de Revolución"
    def __init__(self,parent=None,controles=None):
#        Visor.__init__(self,parent,controles)
        self.parent = parent
        ## ============================
        cilindro = ParametricPlot3D(
            lambda u, t: (cos(u),sin(u), t),  ('t', -pi, pi, 60), ('z', -2, 2, 25),
            addXdelta= .025,  name=u"Cilindro")
        cilindro.addEqn(x**2 + y**2 == 1)
        cilindro.text = u"Un <b>cilindro circular</b> resulta cuando la recta x = 1 del plano XZ rota en torno al eje Z. Note que esta superficie es tanto un cilindro como una superficie de revolución y en consecuencia tiene dos familias infinitas de planos de simetría; las rectas en que se cortan planos de familias distintas son ejes de simetría de la figura."
        ## ============================
        cono = ParametricPlot3D(
            lambda u, t: ((1 - t)* cos(u) + t *cos(u + pi), (1 - t) *sin(u) + t *sin(u + pi), -1 + 2* t),
            ('u', -pi, pi), (0, 1), addXdelta=.025, name = "Cono")
        cono.addEqn(x**2 + y**2 == z**2)
        cono.text = u"Un <b>cono circular</b> con vértice en el origen se obtiene cuando la recta y = z gira en torno al eje Z. Además de los planos por el eje Z, el plano XY es un plano de simetría y las rectas de este plano que pasan por el origen son ejes de simetría de la figura."
        ## ============================
        esfera = ParametricPlot3D(lambda u, t: (cos(t)*cos(u), cos(t)*sin(u), sin(t)),  ( 'u',-pi, pi, 40),  ( -pi/2, pi/2),
            addXdelta = .025, name='Esfera')
#        a = creaVarParam("a")
#        esfera.addParameter(('a', .5,2), 1, qlabel = [a])
        esfera.addEqn(x**2 + y**2 + z**2 == 1)
        esfera.text = u"Una <b>esfera</b> está generada por un círculo, o un semicírculo, que rota en torno a un diámetro. Para la esfera cualquier plano que contenga al centro es un plano de simetría, y cualquier diámetro es un eje de simetría. "
        ## ============================
        hiperboloide = ParametricPlot3D(
            lambda u, z: (sqrt(z**2+1)*cos(u),sqrt(z**2+1)*sin(u),z),  ('u', 0, 2*pi), ('z', -2, 2), addXdelta=.025, name = u"Hiperboloide de <br>un manto")
        hiperboloide.addEqn(z == t)
        hiperboloide.addEqn(x == ('('*t**2+'1)')^'1/2')
        hiperboloide.text = u"Una hipérbola que rota en torno a su eje conjugado forma una superficie de una sola pieza porque cada rama alcanza a la otra. Por eso se llama <b>hiperboloide de un manto</b>. Además de los planos por el eje Z, también el plano XY es un plano de simetría, y todas las rectas de ese plano que contienen al origen son ejes de simetría de esta figura."
        ## ============================
        hiperboloide2 = ParametricPlot3D(lambda r,t: (r*cos(t),r*sin(t),sqrt(1+r**2)), (0, 3, 15), ('u',-pi, pi),
            addYdelta = .025, name = "Hiperboloide de<br>dos mantos")
        hiperboloide2.addQuad(lambda r,t: (r*cos(t),r*sin(t),-sqrt(1+r**2)))
        hiperboloide2.addEqn(z ==  (u'±('*t**2+'1)')^'1/2')
        hiperboloide2.addEqn(x ==  t)
        hiperboloide2.text = u"Una hipérbola que rota en torno a su eje focal forma una superficie con dos pedazos separados, por eso se llama <b>hiperboloide de dos mantos</b>. También en este caso el plano XY es un plano de simetría y las rectas de ese plano que pasan por el origen son ejes de simetría de la figura."
        ## ============================
        ocho = ParametricPlot3D(toRev(lambda t:sin(2*t), sin),  ( 'u',-pi, pi),  ( -pi/2, pi/2),  addXdelta = .025, name='Ocho')
        ## JP
        #~ ocho.addEqn(z == sen(t))
        #~ ocho.addEqn(x == sen(2*t))
        ## Ana Irene
        ocho.addEqn(z == z)
        ocho.addEqn(y == sen(z)*sen(u))
        ocho.addEqn(x == sen(z)*coseno(u))
        ocho.text = u"La curva con ecuaciones paramétricas <em style='font-family:times'>x</em> = sen(2<em style='font-family:times'>t</em>), <em style='font-family:times'>z = t</em>, al girar en torno al eje Z genera una superficie que llamamos <b>ocho</b>, con vértices en los puntos donde la gráfica de sen(2<em style='font-family:times'>t</em>) corta al eje Z."
        ## ============================
        toro = ParametricPlot3D(lambda u,t:((2 + cos(t))*cos(u), (2 + cos(t))*sin(u), sin(t)),  ( 'u',-pi, pi,60 ),  ( 0, 2*pi),
            addXdelta =.025, name='Toro')
        ## JP
        #~ toro.addEqn(z == sen(t))
        #~ toro.addEqn(x == (2+coseno(t)))
        ## Ana Irene
        #~ x^4 + y^4 + z^4 + 2 x^2 y^2 + 2 x^2 z^2 + 2 y^2 z^2 + 2x^2 + 2 y^2 + 6 z^2 + 9 = 0.
        toro.addEqn("" - 10 * x**2 - 10 * y**2 + 6 * z**2 + 9 == 0)
        toro.addEqn("" + 2 * x**2 * y**2  + 2 * x**2 * z**2 + 2 * y**2 * z**2 + "")
        toro.addEqn(x**4 + y**4 + z**4 + "")
        toro.text = u"Un círculo que rota en torno a una recta de su mismo plano pero que no lo corta genera una superficie semejante a una dona llamada <b>toro</b>, de la raíz tor: dar vuelta. Nótese que la ecuación es de cuarto grado."
        ## ============================
        catenoide = ParametricPlot3D(lambda c, u,t:(c*cosh(t/c)*cos(u), c*cosh(t/c)*sin(u), t),  ( 'u',-pi, pi),  ( -2*pi, 2*pi),
            addXdelta = .025, name='Catenoide')
        c = creaVarParam("c")
        catenoide.addParameter(('c', 2,5), 3, qlabel = [c])
        ## JP
        #~ catenoide.addEqn(z==t)
        #~ catenoide.addEqn(x==c * Eq('cosh')(t*'/'*c))
        ## Ana
        catenoide.addEqn(z==z)
        catenoide.addEqn(y==cosenoh(z/c)*sen(u))
        catenoide.addEqn(x==cosenoh(z/c)*coseno(u))
        catenoide.text = u"La curva que forma una cadena colgada entre dos postes se llama catenaria, y cuando rota en torno a la recta que representa el piso forma la superficie llamada <b>catenoide</b>. Como la Superficie de Henneberg, es una superficie mínima que puede obtenerse con una película de jabón. "
        ## ============================
        self.obs1 = [
            cilindro,
            cono,
            esfera,
            hiperboloide,
            hiperboloide2,
            ocho,
            toro,
            catenoide,
        ]
        self.obs2 = [SupRevolucion(*sup) for sup in suprevs]
#        for o in obs:
#            self.addPageChild(o)
#        for sup in suprevs:
#            self.addPageChild(SupRevolucion(*sup))
#        self.whichFigure = 0
    def getPages(self):
        return self.obs1 + self.obs2

    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_ALL
        self.parent.lucesBlanca.on = False
        self.parent.viewer.setTransparencyType(SoGLRenderAction.NONE)
        self.parent.setDrawStyle(SoQtViewer.VIEW_WIREFRAME_OVERLAY)

if __name__ == "__main__":
    app = main(sys.argv)
    window = Revolucion()
    window.resize(400,400)
    window.show()
    window.ui.show()
    SoQt.mainLoop()
