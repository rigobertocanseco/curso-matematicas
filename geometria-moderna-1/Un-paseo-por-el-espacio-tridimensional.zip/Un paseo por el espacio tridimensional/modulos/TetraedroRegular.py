#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
## en python 2.6 no se necesita esto
#from sets import Set
from pivy.gui.soqt import SoQt,  SoQtViewer
from pivy.coin import *
from PyQt4 import QtGui, QtCore, uic
from modulos.util import main, leeArchivo,  conectaParcial,  resta, searchByNodeType,  searchByName,  conecta,  partial, envuelve, OneShot, pjoin
from math import sqrt, cos, sin, asin, pi, pow, cosh, tanh
from Visor import Visor
from Poliedro import Poliedro1 as Poliedro, tubo, esfera
from Simetrias3Dplanos import planosColores

ejesTetra = [
    ((0, 0, -0.367423), (0, 0, 0.775672)),
    ((-0.34641, 0, 0.122474), (0.73131, 0, -0.258557)),
    ((0.173205, -0.3, 0.122474), (-0.365655, 0.633333, -0.258557)),
    ((0.173205, 0.3, 0.122474), (-0.365655, -0.633333, -0.258557))
]

ejesTetra2 = [
    ((-0.144338, -0.25, 0.204124), (0.144338,    0.25, -0.204124)),
    ((-0.144338, 0.25, 0.204124), (0.144338, -0.25, -0.204124)),
    ((0.288675, 0., 0.204124), (-0.288675, 0., -0.204124))
]

## alarga segmentos
def alarga(seg, pc):
    p1, p2 = seg
    res = []
    for j in (-pc, 1 + pc):
        res.append([(p1[i] + (p2[i] - p1[i]) *  j) for i in  range(len(p1)) ])
    return res

sensores = {}

## alarga[{p1_, p2_}, pc_] :=
##   (p1 + (p2 - p1) #) & /@ {-pc, 1 + pc}

class EventFilter(QtCore.QObject):
    def __init__(self, visor):
        QtCore.QObject.__init__(self)
        self.visor = visor

    def eventFilter(self, objeto, evento):
        if evento.type() == QtCore.QEvent.Enter:
            self.visor.ejes[objeto.ejenum].whichChild = 0
            return False
        if evento.type() == QtCore.QEvent.Leave:
            self.visor.ejes[objeto.ejenum].whichChild = -1
            return False
        else:
            return QtCore.QObject.eventFilter(self, objeto, evento)


#eventFilter = EventFilter()
modulosPath = "modulos"

class TetraedroRegular(object):
    name = u"Tetraedro regular"
    def __init__(self,parent=None,uilayout=None):
        self.parent = parent
        self.obs = [self.Tetrahedro()]
        self.procesaPlanos()
#        Visor.__init__(self,parent,uilayout,True, False)
#        ## ============================
#        return
#        self.Tetrahedro()
#        ## ============================
#        self.insertaLuz(SoDirectionalLight())
#        self.whichFigure = 0
#        self.viewer.viewAll()
#        self.viewer.setTransparencyType(SoGLRenderAction.SORTED_LAYERS_BLEND)

    def getPages(self):
        return self.obs

    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_NONE
        self.parent.lucesBlanca.on = True
        self.parent.viewer.setTransparencyType(SoGLRenderAction.SORTED_LAYERS_BLEND)
        self.parent.setDrawStyle(SoQtViewer.VIEW_AS_IS)

    def Tetrahedro(self):
        self.__objeto = QtCore.QObject()
        self.__botonAnterior = 0
        self.__rotacionAnterior = SoRotation()
        ## el ángulo de rotación no puede ser 0.0
        self.__rotacionAnterior.rotation.setValue(SbVec3f(0, 0, 1), 0.0000001)
        ## ============================
        rot1 = SoRotation()
        ## ============================
        ob = Poliedro(leeArchivo(pjoin("modulos","TetraedroRegular","tetraedro.iv")),
            "TetraedroRegular", 1, 0, 0, False)
        ob.root.setName("tetraedro")
        ob.text = u"""En el <b>tetraedro regular</b> ilustramos qué se \
entiende por <b>vértice</b>, qué se entiende por <b>arista</b> y qué se entiende por <b>cara</b>. \
Las caras son 4 triángulos equiláteros congruentes, las aristas son 6 y los \
vértices son 4. El tetraedro queda invariante bajo reflexiones en sus planos de \
simetría, que son 6: los que pasan por una arista y el punto medio de la opuesta, \
y por rotaciones de 120° o 240° en torno al eje que pase por un vértice y el ortocentro \
(punto de intersección de las alturas) de la cara opuesta, o rotaciones de 180° si el eje \
pasa por los puntos medios de aristas opuestas.
La composición de una reflexión en un plano de simetría seguida de cualquiera de estas \
rotaciones es una <b>isometría</b> también deja invariante al tetraedro."""
        ob.root.insertChild(rot1, 0)
        ## ============================
        ## los ejes
        self.ejes = []
        sep = SoSeparator()
        color1 = SoMaterial()
        color2 = SoMaterial()
        color1.diffuseColor = (0, .75, 0)
        color2.diffuseColor = (.81, .4, .55)
        for e in ejesTetra:
            switch = SoSwitch()
            ea = alarga(e, 1.8)
            switch.addChild(tubo(ea[0], ea[1], .005, .99, color1))
            sep.addChild(switch)
            self.ejes.append(switch)
        ## estos hay que alargarlos antes
        for e in ejesTetra2:
            ea = alarga(e, 2)
            switch = SoSwitch()
            switch.addChild(tubo(ea[0], ea[1], .005, .99, color2))
            sep.addChild(switch)
            self.ejes.append(switch)
        switch = SoSwitch()
        switch.setName("ejes")
        switch.addChild(sep)
        switch.whichChild = 0
        ob.root.addChild(switch)
        ## ============================
        self.gui = uic.loadUi(pjoin(modulosPath, "TetraedroRegular","controles.ui"))
        ob.layout().addWidget(self.gui)
        ## ============================
        for i in range(7):
            pb = getattr(self.gui, "r"+str(i+1))
            pb.setMouseTracking(True)
            pb.ejenum = i
            ## necesitamos EventFilter para no tener
            ## que hacer una clase derivada de QPushButton
            pb.ef = EventFilter(self)
            pb.installEventFilter(pb.ef)
            normal = resta((ejesTetra+ejesTetra2)[i][1], (ejesTetra+ejesTetra2)[i][0])
            angulo = 2.0944 if i < 4 else 3.14159
            conectaParcial(pb, "clicked(bool)",self.rotaTetra,rot1,normal,i,angulo)
            for j in range(7):
                bot = getattr(self.gui, "r"+str(j+1))
                conectaParcial(pb, "clicked(bool)", bot.setEnabled)
                conectaParcial(self.__objeto, "terminaRotacion(bool)", bot.setEnabled)
        ## ============================
        ## los planos
        ob.root.ref()
        self.planos = searchByName(ob.root, "planos")
        ## permitimos un valor más. Lo mapeamos al 0
        self.gui.nplanos.setMaximum(len(self.planos)+1)
        conecta(self.gui.nplanos,QtCore.SIGNAL("valueChanged(int)"), self.botonActivado)
        ## ============================
        ## los vértices
        sep = SoSeparator()
        for v in ob.verticesP:
            e = esfera(v, .015)
            sep.addChild(e)
        self.vertices = envuelve(sep, True)
        self.vertices.setName("vertices")
        ob.root.addChild(self.vertices)
        ## ============================
        def setVerticesCB(switch, n):
            if n == 0:
                switch.whichChild = -1
            elif n == 2:
                switch.whichChild = 0
        ## ============================
        conectaParcial(self.gui.vertices, "stateChanged(int)", setVerticesCB, self.vertices)
        ## ============================
        ## las aristas
        sep = SoSeparator()
        for p1, p2 in ob.aristasP:
            seg = tubo(p1, p2, .01, 1, extremos=True)
            sep.addChild(seg)
        self.aristas = envuelve(sep, True)
        self.aristas.setName("aristas")
        ob.root.addChild(self.aristas)
        conectaParcial(self.gui.aristas, "stateChanged(int)", setVerticesCB, self.aristas)
        ## ============================
        ## las caras
        def setCarasCB(n):
            ob.transparency.setValue(1-n/2.0)
        conectaParcial(self.gui.caras, "stateChanged(int)", setVerticesCB, ob.caras)
        ## ============================
        ob.layout().addStretch(1)
        return ob

    ## checked está dado por la señal
    def rotaTetra(self, rot, normal, n, angulo, checked=True):
        rot.rotation.setValue(self.__rotacionAnterior.rotation)
        ## ============================
        def creaRot(normal, angulo):
            ## ============================
            ## necesitamos SoComposeRotation porque no hay
            ## ningún campo que contenga el ángulo de rotación
            ## así que no podemos conectarlo con la salida de
            ## un engine; tiene que ser toda la rotación completa
            ## que Coin guarda como un cuaternio.
            ## ============================
            crot = SoComposeRotation()
            crot.axis.setValue(SbVec3f(*normal))
            crot.angle.setValue(angulo)
            rot2 = SoMFRotation()
            rot2.connectFrom(crot.rotation)
            return rot2.getValues()[0]
        ## ============================
        def oneShotCB(a):
            val1 = creaRot(normal, a * angulo)
            val2 = self.__rotacionAnterior.rotation.getValue()
            rot.rotation.setValue(val1 * val2)
        def finalizaCB(val):
            self.__rotacionAnterior.rotation.setValue(rot.rotation)
            self.__objeto.emit(QtCore.SIGNAL("terminaRotacion(bool)"), True)
        ## ============================
        self.ejes[n].sensor = OneShot(1.0)
        conectaParcial(self.ejes[n].sensor, "ramp(float)", oneShotCB)
        conectaParcial(self.ejes[n].sensor, "finished(bool)", finalizaCB)
        self.ejes[n].sensor.start()
        ## ============================

    def botonActivado(self, n):
        ## hacemos el que el control opere modulo 7
        if n == len(self.planos)+1:
            self.gui.nplanos.setValue(0)
            return
        i = self.__botonAnterior - 1
        if i >= 0:
            self.animaPlano(i,-1)
        if n > 0:
            ## activamos el adecuado (n-1)
            p = self.planos[n-1]
            p.whichChild = 0
            self.animaPlano(n-1,1)
        self.__botonAnterior = n

    def procesaPlanos(self):
        for p, col in zip(self.planos, planosColores):
            sep = p[0]
            mat = searchByNodeType(sep, SoMaterial)
            if mat == None:
                mat = SoMaterial()
                ## plano[0] es un SoSeparator
                sep.insertChild(mat, 0)
            mat.ambientColor = (0, 0, 0)
            mat.diffuseColor = (0, 0, 0)
            mat.emissiveColor = col


    def animaPlano(self, n, dir = 1):
        mat = searchByNodeType(self.planos[n], SoMaterial)
        ## ============================
        counter = SoOneShot()
        counter.duration = 0.3
        counter.trigger.touch()
        counter.flags = SoOneShot.HOLD_FINAL
        ## ============================
        calc = SoCalculator()
        calc.a.connectFrom(counter.ramp)
        ## oa va de 1 a 0.1
        calc.expression.set1Value(0, "oa=1-a*.9")
        ## ob de 0.1 a 1
        calc.expression.set1Value(1, "ob=1-(1-a)*.9")
        ## ============================
        if dir == 1 and sensores.has_key(n):
            sensores[n].detach()
        elif dir == -1:
            if not sensores.has_key(n):
                sensores[n] = SoFieldSensor(partial(finalizaCB,self.planos[n],dir), mat)
            sensores[n].attach(mat.transparency)
        mat.transparency.connectFrom(calc.oa if dir == 1 else calc.ob)

def finalizaCB(plano, dir, mat, sensor):
    tr = mat.transparency.getValues()[0]
    if dir == -1:
        if 1.0 - tr < .00001:
            plano.whichChild = -1



def setSwitchCB(switch, n):
    if n == 0:
        switch.whichChild = -1
    elif n == 2:
        switch.whichChild = 0


if __name__ == "__main__":
    app = main(sys.argv)
    window = TetraedroRegular()
    window.resize(500, 500)
    window.rotor.on = False
    window.show()
    window.ui.show()
    SoQt.mainLoop()

