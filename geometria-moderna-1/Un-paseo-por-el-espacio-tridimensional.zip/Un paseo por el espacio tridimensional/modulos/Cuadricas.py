#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
from pivy.gui.soqt import *
from pivy.coin import *
from PyQt4 import QtGui, QtCore, uic
from modulos.util import main, lee,  conecta
from math import sqrt, cos, sin, asin, pi, pow
from MallaBase2 import MallaBase,  ParametricPlot3D,  creaVars,  Eq,  creaVarParam, creaOpParam
from Visor import Visor
#import psyco
#~ psyco.full()
x, y, z, l= creaVars(['x', 'y', 'z', '1'])

class F2a3(MallaBase):
    name = u"Paraboloide Elíptico"
    def __init__(self):
        MallaBase.__init__(self, ('x', self.rango), (-pi, pi))
        w = creaVarParam('w')
        lw = creaOpParam('(1-w)', 'w')
        self.addParameter(('w', 0,0.999), qlabel = [w, lw])
        self.addEqn(x**2+2*y**2+lw*z**2-w * z == 1)
        self.text = u"Cuando uno de los vértices del elipsoide se aleja indefinidamente, las elipses que lo contienen se vuelven parábolas  y el elipsoide se convierte en un paraboloide elíptico."

    def func(self,w):
        a = w/(2*(w - 1))
        b = 1/(1-w)
        c = w**2/(4*(w-1))
        return lambda t,th: (
            cos(th)*sqrt(1-c)*cos(t),
            sin(th)*sqrt(1-c)*cos(t)/sqrt(2),
            sqrt(b*(1-c))*sin(t)-a)
    def rango(self,w=0):
        tmax = pi/2
        if w > 2.0/3.0:
            tmax = asin((-6 + 7*w)/(sqrt((-2 + w)**2/(-1 + w)**2)*(-1 + w)))
        return (-pi/2,tmax, 40)

class F3a4(MallaBase):
    name = u"Recta"
    def __init__(self):
        self.a = .0002
        MallaBase.__init__(self, ('x', self.rango), (-pi, pi))
        lw = creaOpParam('(1-w)', 'w')
        self.addParameter(('w', 0,0.99999), qlabel=[lw])
        self.addQuad(lambda w, r,t: (r*cos(t), r*sin(t)/sqrt(2),  (1+self.a-r**2-w)/(-1+w)))
        self.addEqn( x**2 + 2*y**2 - lw*'('*l+ z*')'==0 )
        self.text = u"Cuando el paraboloide elíptico se contrae hacia su eje de simetría, el paraboloide elíptico degenera en una recta , el eje Z en este caso."
        
    def rango(self, w=0):
        a = self.a
        w0 = (2 -a)/2
        rmax=sqrt(4- a/(-1+w))*sqrt(1-w)
        if w < w0:
            rmin = 0
        else:
            rmin = sqrt(-2 - a/(-1 + w))* sqrt(1 - w)
        return (rmin, rmax, 40)

class F5a6(MallaBase):
    name = u"Cilindro Parabólico"
    def __init__(self):
        MallaBase.__init__(self, ('x', self.rango), (-3, 3))
        w = creaVarParam('w')
        lw = creaOpParam('(1-w)', 'w')
        self.addParameter(('w', 0,0.99999), qlabel=[w, lw])
        self.addEqn(x**2+2*y**2*lw+y * w == 1)
        self.text = u"Si una generatriz del cilindro elíptico se aleja indefinidamente, las elipses que contienen uno de los puntos de la generatriz se convierten en parábolas y resulta un cilindro parabólico."
        
    def func(self,w):
        a = w/(4*(1-w))
        c = 1+2*a**2 *(1-w)
        return lambda t,th: (
            sqrt(c)*cos(t),
            sqrt(c/(2*(1 - w)))*sin(t) - a, th)
    def rango(self,w=0):
        rmin = -pi/2
        rmax = 3.0/2.0 * pi
        if w > 17.0/21.0:
            r56 = asin((12 - 13*w)/((-1 + w)*sqrt((8 + (-8 + w)*w)/(-1 + w)**2)))
            rmin = r56
            rmax = pi - r56
        return (rmin,rmax, 40)

class F6a7(MallaBase):
    name = u"Planos Paralelos"
    def __init__(self):
        MallaBase.__init__(self, (-3, 3, 30), ('y', self.rango))
        w = creaVarParam('w')
        lw = creaOpParam('(1-w)', 'w')
        self.addParameter(('w', 0,0.99), qlabel=[w, lw])
        self.addQuad(lambda w, z, y: ( +sqrt(abs(-(-1+y)* (1+w * y)))   / sqrt(1-w),y,z))
        self.addQuad(lambda w, z, y: (   -sqrt(abs(-(-1+y)* (1+w * y)))  / sqrt(1-w),y,z))
        self.addEqn(lw* x**2+w* y**2+lw*y == 1)
        self.text = u"Si la generatriz del cilindro parábolico que contiene a los vértices de las parábolas directrices se aleja indefinidamente, las parábolas directrices se convierten dos rectas paralelas y todas ellas están contenidas en dos planos paralelos."
        
    def rango(self, w=0):
        if w < 1.0/3:
            return (-3, 1, 40)
        else:
            return (-1/w, 1, 40)

class F7a8(MallaBase):
    name = u"Plano Doble"
    def __init__(self):
        MallaBase.__init__(self, (-3, 3, 10), (-3, 3, 10))
        lw = creaOpParam('(1-w)', 'w')
        self.addParameter(('w', 0,1), qlabel=[lw])
        self.addQuad(lambda w,x,z: (x,sqrt(1-w),z))
        self.addQuad(lambda w,x,z: (x,-sqrt(1-w),z))
        self.addEqn(y**2 == lw)
        self.text = u"Si los planos paralelos se acercan hasta tocarse resulta un plano doble. "

class F8a9(MallaBase):
    name = u"Planos que<br>se cortan"
    def __init__(self):
        MallaBase.__init__(self, (-3, 3, 10), (-3, 3, 10))
        w = creaVarParam('w')
        self.addParameter(('w', 0,1), qlabel=w)
        self.addQuad(lambda w,x,z: (x,sqrt(w)*x,z))
        self.addQuad(lambda w,x,z: (x,-sqrt(w)*x,z))
        self.addEqn(y**2 - w * x**2 == 0)
        self.text = u"Si un plano gira y el otro permanece fijo, conservan una recta en común."

class F9a10(MallaBase):
    name = u"Cilindro Hiperbólico"
    def __init__(self):
        MallaBase.__init__(self, (-3, 3, 50), (-3, 3, 30))
        w = creaVarParam('w')
        self.addParameter(('w', 0,1), qlabel=w)
        self.addQuad(lambda w,x,z: (x,sqrt(w+x**2),z))
        self.addQuad(lambda w,x,z: (x,-sqrt(w+x**2),z))
        self.addEqn( "" -x**2 + y**2 == w)
        self.text = u"Las asíntotas de una hipérbola pueden verse como el caso límite de hipérbolas  con esas asíntotas cuando los vértices se acercan hasta volverse uno solo; aquí partimos del cilindro sobre las asíntotas y tomamos cilindros sobre hipérbolas cuyos vértices se alejan conservando las asíntotas. "

class F10a11(MallaBase):
    name = u"Hiperboloide de<br>dos mantos"
    def __init__(self):
        MallaBase.__init__(self, (-3, 3, 30), (-3, 3, 30))
        w = creaVarParam('w')
        self.addParameter(('w', 0,1), qlabel=w)
        self.addQuad(lambda w,x,z: (x,sqrt(1+x**2+w*z**2),z))
        self.addQuad(lambda w,x,z: (x,-sqrt(1+x**2+w*z**2),z))
        self.addEqn( "" -x**2 + y**2 - w * z**2 == 1)
        self.text = u"Si las generatrices del cilindro que contienen a los vértices de las ramas se vuelven ramas de una hipérbola, el cilindro hiperbólico se convierte en un hiperboloide de dos mantos."

class F11a12(MallaBase):
    name = u"Cono Elíptico"
    def __init__(self):
        MallaBase.__init__(self, ('x', lambda w=0: (0,sqrt(8+w), 20)), (-pi, pi, 55))
        lw = creaOpParam('(1-w)', 'w')
        self.addParameter(('w', 0,1), qlabel=[lw])
        self.addQuad(lambda w, r,t: (r*cos(t),sqrt(1+r**2-w),r*sin(t)))
        self.addQuad(lambda w, r,t: (r*cos(t),-sqrt(1+r**2-w),r*sin(t)))
        self.addEqn( x**2 - y**2 + z**2  == - lw )
        self.text = u"Un cono elíptico es el caso intermedio entre un hiperboloide de dos mantos y otro de un manto, así como las asíntotas son el caso intermedio entre dos familias de hipérbolas que comparten las asíntotas, las que tiene eje focal en una de las bisectrices de las asíntotas, y las que tiene eje focal en la otra bisectriz."

class F12a13(MallaBase):
    name =u"Hiperboloide<br>de una hoja"
    def __init__(self):
        MallaBase.__init__(self, ('x', lambda w=0: (sqrt(w),sqrt(9+0*w), 20)), (-pi, pi, 55))
        w = creaVarParam('w')
        self.addParameter(('w', 0,1), qlabel=w)
        self.addQuad(lambda w, r,t: (r*cos(t),sqrt(abs(r**2-w)),r*sin(t)))
        self.addQuad(lambda w, r,t: (r*cos(t),-sqrt(abs(r**2-w)),r*sin(t)))
        self.addEqn( x**2 - y**2 + z**2  == w )
        self.text = u"Si el vértice del cono elíptico se convierte en un círculo, obtenemos un hiperboloide de un manto."

class F13a14(MallaBase):
    name = u"Paraboloide Hiperbólico"
    def __init__(self):
        MallaBase.__init__(self, ('x', self.rangox2), ('y', self.rangot))
        w = creaVarParam('w')
        lw = creaOpParam('(1-w)', 'w')
        self.addParameter(('w', 0,.9), qlabel=[w, lw])
#        psyco.bind(self.func1)
#        psyco.bind(self.func1)
        self.addQuad(self.func1)
        self.addQuad(self.func2)
        self.addEqn( x**2 - y**2 + lw * z**2 + w* z == 1)
        self.text = u"Si los vértices de elipses que se ubican en una rama de una hipérbola se alejan indefinidamente, las elipses se convierten en parábolas y resulta un paraboloide hiperbólico. Esta superficie fue descubierta por Euler."
        
    ## si w=0
    ## => a = 4
    ## => xmin = 1
    ## => xmax = sqrt(10) ~ 3.16228
    def rangox(self,w=0):
        a = sqrt(16 - 16*w + pow(w,2))
        return (
            (2*sqrt(pow(-2 + w,2)))/a,
            (2*sqrt(40 - 40*w + pow(w,2)))/a, 40)

    def rangox2(self,w=0):
        a = sqrt(16 - 16*w + pow(w,2))
        return ((2*sqrt(pow(-2 + w,2)))/a,3, 40)

    def rangot(self, w=0):
        t0 = -asin((2 * (-6+7 * w))/(7 * (-1+w) * sqrt((16-16 * w+w**2)/(-1+w)**2)))
        tmin = t0
#        tmin = -pi/2
        if w<.89:
            tmin = -pi/2
        dif = tmin + pi/2
        tmax = pi * 3/2 - dif
        return(tmin, tmax, 40)

    @staticmethod
    def func1(w, r, t):
        a = 16 -16*w +w**2
        b = -1 + w
        return (
            .25*r*sqrt(a/(1 - w))*cos(t),
            .25*sqrt(abs(((-a)*pow(r,2) + 4*pow(-2 + w,2))/b)),
            (2*w + sqrt(a/pow(b,2))*b*r*sin(t))/(4*b))

    @staticmethod
    def func2(w, r, t):
        a = 16 -16*w +w**2
        b = -1 + w
        return (
            .25*r*sqrt(a/(1 - w))*cos(t),
            -.25*sqrt(abs(((-a)*pow(r,2) + 4*pow(-2 + w,2))/b)),
            (2*w + sqrt(a/pow(b,2))*b*r*sin(t))/(4*b))

class Cuadricas(QtCore.QObject):
    name = "Cuadricas"
    def __init__(self,parent=None,controles=None):
        QtCore.QObject.__init__(self)
        self.parent = parent
        ## ============================
        self.prolog = SoGroup()
        ## ============================
        w = creaVarParam('w')
        f1a2 = ParametricPlot3D(lambda w, u,v: (w*cos(u)*cos(v), (w*cos(v)*sin(u))/sqrt(w+1), w*sin(v)),
            ('u', -pi, pi), (-pi/2,pi/2), extraParms=[(('w', 0,1),0.01, w)], name="Elipsoide")
        f1a2.addEqn(x**2+2*y**2+z**2 == w)
        f1a2.text = u"Si <em>w</em> = 0 sólo tenemos un punto, el origen (0, 0, 0), y si <em>w</em> es mayor que 0 el lugar geométrico de la ecuación es un elipsoide"
        ## ============================
        w = creaVarParam('w')
        f4a5 = ParametricPlot3D(lambda w, r,t: (sqrt(w)*cos(t), sqrt(w)*sin(t)/sqrt(2),r), (-3, 3), (-pi, pi),
                extraParms=[(('w', 0.0001,1),0, w)], name=u"Cilindro Elíptico")
        f4a5.addEqn(x**2+2*y**2 == w)
        f4a5.text = u"Si un cilindro elíptico se contrae hacia su eje de simetría, degenera en una recta; aquí invertimos el proceso."
        ## ============================
        texto = """
        ClipPlane {
            plane 0 0 1  %s
        }
        ClipPlane {
            plane 0 0 -1  %s
        }
        ClipPlane {
            plane 0 1 0  %s
        }
        ClipPlane {
            plane 0 -1 0  %s
        }
        ClipPlane {
            plane 1 0 0  %s
        }
        ClipPlane {
            plane -1 0 0  %s
        }
        """ % (lambda x:(x, x, x, x, x, x))(-3.01)
        planos = lee(texto)
        ## las tenemos que insertar antes del switch (que es el ultimo elemento
        ## de self.root
        self.planos = []
        for p in planos:
            self.prolog.addChild(p)
            self.planos.append(p)
        ## ============================
        self.obs = [
            f1a2,
            F2a3(),
            F3a4(),
            f4a5,
            F5a6(),
            F6a7(),
            F7a8(),
            F8a9(),
            F9a10(),
            F10a11(),
            F11a12(),
            F12a13(),
            F13a14()
        ]
        ## ============================
        self.viewAlloriginal = self.parent.viewer.viewAll
        ## ============================
        conecta(self, QtCore.SIGNAL("cambiaFigura(int)"), self.onCambiaFigura)
        self.lastPlanoOffset = -3.01

    def getPages(self):
        return self.obs
    def getProlog(self):
        return self.prolog

    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_ALL
        self.parent.lucesBlanca.on = False
        self.parent.viewer.setTransparencyType(SoGLRenderAction.NONE)
        self.parent.setDrawStyle(SoQtViewer.VIEW_WIREFRAME_OVERLAY)
        self.parent.viewer.viewAll = lambda:1
        cubo = SoCube()
        cubo.width = 6
        cubo.height = 6
        cubo.depth = 6
        camera = self.parent.viewer.getCamera()
        camera.viewAll(cubo, self.parent.viewer.getViewportRegion())

    def chapterSpecificOut(self):
        self.parent.viewer.viewAll = self.viewAlloriginal

    def onCambiaFigura(self, n):
        ## esperamos la última figura
        if n == 12:
            self.setPlanoOffset(-3.7)
        else:
            self.setPlanoOffset(-3.01)

    def setPlanoOffset(self, x):
        dif = x - self.lastPlanoOffset
        for p in self.planos:
            p.plane.getValue().offset(dif)
#            print p.plane.getValue().getDistanceFromOrigin()
        self.lastPlanoOffset = x
#        self.viewer.viewAll()


#~ if __name__ == "__main__":
    #~ app = main(sys.argv)
    #~ visor = Visor()
    #~ window = Cuadricas(visor)
    #~ visor.addChapter(window)
#~ #    window.show()
#~ #    window.ui.show()
    #~ SoQt.mainLoop()

if __name__ == "__main__":
    c = F13a14()
    c.updateAll()

