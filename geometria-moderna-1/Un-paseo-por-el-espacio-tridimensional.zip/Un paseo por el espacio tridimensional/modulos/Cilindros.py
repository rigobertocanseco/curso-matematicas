#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from pivy.gui.soqt import *
from pivy.coin import *
from PyQt4 import QtGui, QtCore, uic
from modulos.util import main
from math import sqrt, cos, sin, asin, pi, pow, exp
from MallaBase2 import MallaBase,  ParametricPlot3D,  creaVars
from Visor import Visor


class Cilindros(object):
    name = "Cilindros"
    def __init__(self,parent=None,controles=None):
#        Visor.__init__(self,parent,controles)
        self.parent = parent
        x, y, z, a, b, sen, r, e , t, w = creaVars(['x', 'y', 'z','a', 'b', 'sen', 'r', 'exp', 't', 'w'])
        ## ============================
        cilindroEliptico = ParametricPlot3D(
            lambda u, t: (cos(u),sin(u), t),  (-pi, pi, 60), ('z', -2, 2, 25), addYdelta= .025,  name=u"Cilindro Elíptico")
        cilindroEliptico.addEqn(x**2 / a**2 + y**2 / b**2 == 1)
        cilindroEliptico.text = u"Este <b>cilindro elíptico</b> tiene generatrices paralelas al eje Z, infinitos planos de simetría paralelos al plano XY, y dos planos de simetría perpendiculares entre sí que se levantan sobre los ejes focal y conjugado de la elipse directriz."
        ## ============================
        cilindroParabolico = ParametricPlot3D(
            lambda x, z: (x,-x**2,z),  (-3, 3, 40), ('z', -3, 3, 20), addYdelta=.025, name = u"Cilindro Parabólico")
        cilindroParabolico.addEqn(y == x**2)
        cilindroParabolico.text = u"Para este <b>cilindro parabólico</b> las generatrices también son paralelas al eje Z, tiene infinitos planos de simetría paralelos al plano XY y además el plano que se levanta sobre el eje focal de la parábola. La parábola directriz tiene eje focal paralelo al eje Y."
        ## ============================
        cilindroHiperbolico = ParametricPlot3D(
            lambda x, z: (x,sqrt(x**2+1),z),  (-3, 3), ('z', -3, 3), addYdelta=.025, name = u"Cilindro Hiperbólico")
        cilindroHiperbolico.addQuad(lambda x, z: (x,-sqrt(x**2+1),z))
        cilindroHiperbolico.addEqn(y**2 - x**2 == 1)
        cilindroHiperbolico.text = u"Este <b>cilindro hiperbólico</b> tiene generatrices paralelas al eje Z, infinitos planos de simetría paralelos al plano XY, y dos planos perpendiculares a los anteriores que se levantan sobre el eje focal y el eje conjugado de la hipérbola directriz es el eje Y."
        ## ============================
        planosCortan = ParametricPlot3D(lambda x,z: (x,x,z),  (-3, 3), ('z', -3, 3), addYdelta=.025,
            name = u"Planos que<br>se cortan")
        planosCortan.addQuad(lambda x,z: (x,-x,z))
        planosCortan.addEqn(y**2 -  x**2 == 0)
        planosCortan.text = u"<b>Dos planos que se cortan</b> forman un cilindro que se levanta sobre las rectas que se cortan en el plano XY dadas por la ecuación en el panel. Sus generatrices son paralelas al eje Z y los infinitos planos de simetría son perpendiculares a dicho eje. Los planos bisectores de los dos ángulos formados entre los planos también son planos de simetría."
        ## ============================
        planoDoble = ParametricPlot3D(lambda x, z: (x,1,z), (-3, 3), ('z', -3, 3), addYdelta=.025,
            name=u"Planos Paralelos")
        planoDoble.addQuad(lambda x, z: (x,-1,z),col=(1,0,0))
        planoDoble.addEqn(y**2==1)
        planoDoble.text = u"<b>Dos planos paralelos</b>, de ecuaciones y = 1, y = -1, constituyen el cilindro sobre dos rectas paralelas; como x y z son libres los planos son paralelos al plano XZ. Esta vez, los infinitos planos de simetría son todos los planos que contengan a una recta perpendicular a ellos, además del plano equidistante entre ambos. "
        ## ============================
        senoide = ParametricPlot3D(lambda x, z: (x,sin(x),z),  (0, 8*pi, 100), ('z', -3, 3, 20), addYdelta=.025,
            name = u"Cilindro Sinusoidal")
        senoide.addEqn(y == sen(x))
        senoide.text = u"Un <b>cilindro sinusoidal</b> se levanta sobre la gráfica del seno, y = sen x, y semeja un techo acanalado. Hay infinitos planos de simetría perpendiculares a las generatrices."
        ## ============================
        espiral = ParametricPlot3D(lambda t, z: (exp(-.2*t)*cos(t),exp(-.2*t)*sin(t),z),  (0, 8*pi, 180), ('z', 0, 1, 15),
            addYdelta=.025, name = u"Cilindro Espiraloide")
        espiral.addEqn(r == e(-0.2*t))
        espiral.text = u"Un <b>cilindro espiraloide</b> tiene como curva directriz una espiral. La ecuación está dada en coordenadas polares para el plano de la curva. Los planos de simetría son perpendiculares a las generatrices"
        self.obs = [
            cilindroEliptico,
            cilindroParabolico,
            cilindroHiperbolico,
            planosCortan,
            planoDoble,
            senoide,
            espiral
        ]

    def getPages(self):
        return self.obs

    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_ALL
        self.parent.lucesBlanca.on = False
        self.parent.viewer.setTransparencyType(SoGLRenderAction.NONE)
        self.parent.setDrawStyle(SoQtViewer.VIEW_WIREFRAME_OVERLAY)

if __name__ == "__main__":
    app = main(sys.argv)
    window = Cilindros()
    window.resize(400,400)
    window.show()
    window.ui.show()
    SoQt.mainLoop()
