# -*- coding: utf-8 -*-
# ui, modulo, nombre

orden = [
###    "Presentacion",
    "PlanosDeSimetria",
    "TetraedroRegular",
    "Simetrias3D",
    "Cilindros", 
    "Revolucion",
    "Regladas",
    "Cuadricas",
    "Platonicos",
    "KeplerPoinsot",
    "Arquimedeanos"
]
