from PyQt4 import QtGui, QtCore, uic
from Parametro import Param1
import sys

def f(x):
    print x
    
app = QtGui.QApplication(sys.argv)
p1 = Param1(0, 1, 5, f, sys.exit)
p1.start(10)
app.exec_()
