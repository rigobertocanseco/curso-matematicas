#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os.path
from pivy.gui.soqt import SoQt,  SoQtViewer
from pivy.coin import SO_SWITCH_NONE, SoComplexity, SoGLRenderAction
from modulos.util import main, leeArchivo, pjoin, viewVolume
from Poliedro import Poliedro1 as Poliedro

def moduloPath(name):
    return pjoin("modulos","arquimedeanos",name)

textos = [
    u"El <b>tetraedro truncado</b> resulta de cortar el tetraedro con planos que pasen por los puntos correspondientes a la tercera parte de cada arista concurrente en un vértice. Las caras son entonces triángulos equiláteros y hexágonos regulares; en cada vértice inciden 2 hexágonos y 1 triángulo.",
    u"El <b>cuboctaedro</b>, inscrito simultáneamente en un cubo y en un octaedro, tiene por caras  6 cuadrados y 8 triángulos; en cada vértice concurren 2 triángulos y 2 cuadrados.",    
    u"El <b>cubo truncado</b> recorta de cada vértice del cubo un tetraedro; se forman así caras octagonales (6) y triangulares (8), y en cada vértice concurren 2 octágonos y 1 triángulo.",
    u"El <b>octaedro truncado</b> recorta de cada vértice una pirámide cuadrangular, por lo que obtenemos cuadrados (6) y hexágonos (8), y en cada vértice concurren 2 hexágonos y 1 cuadrado.",
    u"El <b>rombicuboctaedro</b> está inscrito en un cubo, un octaedro y un rombidodecaedro; consta de 16 cuadrados y 8 triángulos; en cada vértice concurren 3 cuadrados y 1 triángulo.",
    u"El <b>cuboctaedro truncado</b> recorta de cada vértice una pirámide cuadrangular y resultan cuadrados (12), hexágonos (8) y octágonos (6); en cada vértice concurre 1 cara de cada tipo.",
    
    u"El <b>cuboctaedro chato</b> consta de 24 triángulos y 6 cuadrados; en cada vértice concurren 4 triángulos y 1 cuadrado.",
    u"El <b>icosidodecaedro</b> resulta al recortar de los vértices de un dodecaedro pirámides triangulares que agotan las aristas; resultan entonces pentágonos (12) y triángulos (20), y cada vértice concurren 2 pentágonos y 2 triángulos.",
    
    u"El <b>dodecaedro truncado</b> recorta de cada vértice un tetraedro, lo cual origina triángulos (20) y decágonos (12); en cada vértice concurren 2 decágonos y 1 triángulo.",
    u"El <b>icosaedro truncado</b> recorta de cada vértice una pirámide pentagonal, lo cual origina pentágonos (12) y hexágonos (20). En cada vértice concurren 2 hexágonos y 1 pentágono.",
    u"El <b>rombicosidodecaedro</b>, inscrito en un dodecaedro, un icosaedro y el sólido rómbico de 30 caras, consta de 20 triángulos, 30 cuadrados y 12 pentágonos; en cada vértice concurren 1 triángulo, 2 cuadrados y 1 pentágono.",
    u"El <b>icosidodecaedro truncado</b> recorta de cada vértice una pirámide cuadrangular; resultan entonces cuadrados (30), hexágonos (20) y decágonos (12), y en cada vértice concurre un polígono de cada tipo.",
    u"El <b>dodecaedro chato</b> consta de 60 triángulos y 12 pentágonos; en cada vértice concurren 1 pentágono y 4 triángulos."
]
class Arquimedeanos(object):
    name = u"Sólidos Arquimedeanos"
    def __init__(self,parent=None,uilayout=None):
        self.parent = parent
        self.viewAlloriginal = self.parent.viewer.viewAll
        self.objetos = []
        archivos = [
            ("truncated_tetrahedron", "Tetraedro<br>truncado", 8, 18, 12), 
            ("cuboctahedron", "Cuboctaedro", 14, 24, 12), 
            ("truncated_cube", "Cubo truncado", 14, 36, 24), 
            ("truncated_octahedron", "Octaedro<br>truncado", 14, 36, 24), 
            ("rhombicuboctahedron","Rombicuboctaedro", 26, 48, 24), 
            ("truncated_cuboctahedron", "Cuboctaedro<br>truncado", 26, 72, 48), 
            ("snub_cuboctahedron","Cuboctaedro<br>chato", 38, 60, 24), 
            ("icosidodecahedron","Icosidodecaedro", 32, 60, 30), 
            ("truncated_dodecahedron", "Dodecaedro<br>truncado", 32, 90, 60), 
            ("truncated_icosahedron","Icosaedro<br>truncado", 32, 90, 60), 
            ("rhombicosidodecahedron","Rombicosi-<br>dodecaedro", 62, 120, 60), 
            ("truncated_icosidodecahedron", "Icosidodecaedro<br>truncado", 62, 180, 120), 
            ("snub_icosidodecahedron", "Dodecaedro<br>chato", 92, 150, 60), 
        ]
        
        for i, a in enumerate(archivos):
            f, n = a[:2]
            svgfile = moduloPath(f+"_flat.svg")
            pngfile = moduloPath(f+"_flat.png")
            file = svgfile if os.path.exists(svgfile) else pngfile
            datos = list(a[2:5]) + [file]
            escala = a[5] if len(a) == 6 else 2
            ob = Poliedro(leeArchivo(moduloPath(f+".wrl")), nombre=n, datos=datos, scale=escala)
            ob.text = textos[i]
            ob.transparency.setValue(0)
            ob.setVertexRadius(ob.escala)
            ob.setAristasRadio(ob.escala*0.5)
            ## ============================
            self.objetos.append(ob)

    def getPages(self):
        return self.objetos
    
    def getProlog(self):
        com = SoComplexity()
        com.value = .4
        return com
        
    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_NONE
        self.parent.lucesBlanca.on = True
        self.parent.viewer.setTransparencyType(SoGLRenderAction.SORTED_LAYERS_BLEND)
        self.parent.setDrawStyle(SoQtViewer.VIEW_AS_IS)
        self.parent.viewer.viewAll = lambda:1
        viewVolume(self.parent.viewer, 4)
        
    def chapterSpecificOut(self):
        self.parent.viewer.viewAll = self.viewAlloriginal
        
if __name__ == "__main__":
    app = main()
    window = Arquimedeanos()
    window.show()
    window.ui.show()
    SoQt.mainLoop()
    
