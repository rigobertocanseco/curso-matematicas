#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

from pivy.gui.soqt import *
from pivy.coin import *
from PyQt4 import QtGui, QtCore, uic
from modulos.util import main,  leeArchivo,  searchByName,  conecta
from modulos.util import searchByNodeType, pjoin

modulosPath = "modulos"

planos_fclass, base_class = uic.loadUiType(pjoin(modulosPath, "Simetrias3D","planos.ui"))

## para no tener que cargar el mismo archivo varias veces
class PlanosUi(base_class, planos_fclass):
    def __init__(self, *args):
        QtGui.QWidget.__init__(self, *args)
        self.setupUi(self)


planosColores = [
    (.67, .67, 1), # lila
    (.81, .4, .55), 
    (.37, .67, .72), 
    (0, .75, 0), # verde claro
    (.75, 0, 0), # rojo
    (0, .33, 1), # azul
    (.79, .53, 0), 
    (1, .33, .5), 
    (.33, .67, 1), 
    ]        

class PlanosDeSimetria(QtCore.QObject):
    name = u"Planos de Simetría"
    def __init__(self,parent=None,uilayout=None):
        QtCore.QObject.__init__(self)
        self.parent = parent
        expr = {'c':"<sup>2</sup>", 
            'x':"<em style='font-family:serif;'>x</em>", 
            'y':"<em style='font-family:serif;'>y</em>", 
            'z':"<em style='font-family:serif;'>z</em>"}
        self.archivos = [
            ("vaca + 1 plano",u"Mamífero<br>(simetría bilateral)", 
                u"Un <b>mamífero</b> sólo tiene un plano de simetría."), 
            ("henneberg + 2 planos","Superficie de<br>Henneberg<br>2 planos", 
                u"""La <b>Superficie de Henneberg</b> sólo tiene dos planos de simetría \
perpendiculares entre sí. Esta superficie puede realizarse con \
una película de jabón si el alambre tiene la forma del borde, lo \
cual la identifica como una <b>superficie mínima</b>."""), 
            ("seno-y + 3 planos","Seno complejo<br>3 planos", u"La superficie llamada <b>seno complejo</b> tiene tres planos de simetría perpendiculares entre sí. Proviene de la función compleja seno, aunque ignora una de las cuatro coordenadas."), 
            ("superficie1 + 9 planos", "Superficie de nivel<br>" +\
                "%(x)s%(c)s %(y)s%(c)s+%(x)s%(c)s %(z)s%(c)s+%(y)s%(c)s %(z)s%(c)s=1<br>"  % expr+ \
                "9 planos", u"La <b>superficie de nivel 1</b> (de la función indicada arriba ) tiene tantos planos de simetría como un <b>cubo</b> o un <b>octaedro</b>: los planos que contienen diagonales paralelas de caras opuestas (2 x 3 = 6), y los planos equidistantes de caras opuestas (3)."), 
            ]
        self.pages = []
        for f,nom,texto in self.archivos:
            self.pages.append(ObjetoSimetria(leeArchivo(pjoin("modulos","Simetrias3D","%s.iv"%f)),nombre=nom, text=texto))
        
   
    def getPages(self):
        return self.pages
        
    def getProlog(self):
        grp = SoGroup()
        env = SoEnvironment()
        env.ambientIntensity = 0
        grp.addChild(env)
        return grp
    
    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_ALL
        self.parent.lucesBlanca.on = False
        self.parent.viewer.setTransparencyType(SoGLRenderAction.SORTED_LAYERS_BLEND)
        self.parent.setDrawStyle(SoQtViewer.VIEW_AS_IS)
        
class ObjetoSimetria(object):
    def __init__(self,  root,  nombre="", text=""):
        self.root = root
        root.ref()
        self.name = nombre
        self.text = text
        self.planos = searchByName(root, "planos")
        self.setupGui()
        self.procesaPlanos()

    def getGui(self):
        return self.paramW
    
    def setupGui(self):
        "agrega el widget para los parámetros + el título"
        self.paramW = PlanosUi()
        self.paramW.play.hide()
        self.paramW.nplanos.setMaximum(len(self.planos))
        conecta(self.paramW.nplanos,QtCore.SIGNAL( "valueChanged(int)"),  self.botonActivado)
        self.paramW.nombre.setText("<h2><center>%s</center></h2>" % self.name)
        ## ============================
        
# TODO: Audio
#        conecta(self.paramW.audio.)
        ## ============================
#        return
#        label = QtGui.QLabel("<h3>transparencia:</h3>")
#        label.setAlignment(QtCore.Qt.AlignHCenter)
#        self.paramW.layout().addWidget(label)
#        ## ============================
#        sl = QtGui.QSlider(QtCore.Qt.Horizontal,  self.paramW)
#        maxSL = 50
#        sl.setMaximum(0)
#        sl.setMaximum(maxSL)
#        sl.setValue(maxSL*.3)
#        self.conectaPlanos(sl)
#        ## ============================
#        self.paramW.layout().addWidget(sl)
#    
#    def conectaPlanos(self, slider):
#        for p in self.planos:
#            ## p es in SoSwitch
#            ## en este momento el plano p no es visible,
#            ## por eso searchByNodeType no encuentra el material
#            ## p[0] es un SoSeparator
#            mat = searchByNodeType(p[0], SoMaterial)
#            if mat == None:
#                mat = SoMaterial()
#                p[0].insertChild(mat, 0)
#            maxSL = slider.maximum()
#            conectaParcial(slider, "valueChanged(int)", 
#               lambda mat,  n: mat.transparency.setValue(n/float(maxSL)),  mat)
    
    def botonActivado(self, n):
        ## activamos los adecuados
        for i in range(n):
            p = self.planos[i]
            if p.whichChild.getValue() == -1:
                p.whichChild = 0
                animaPlano(p)
        ## desactivamos el resto
        for i in range(n, len(self.planos)):
            self.planos[i].whichChild = -1
    
    def procesaPlanos(self):
        for p, col in zip(self.planos, planosColores):
            sep = p[0]
            mat = searchByNodeType(sep, SoMaterial)
            if mat == None:
                mat = SoMaterial()
                ## plano[0] es un SoSeparator
                sep.insertChild(mat, 0)
            mat.ambientColor = (0, 0, 0)
            mat.diffuseColor = (0, 0, 0)
            mat.emissiveColor = col
    
def animaPlano(plano):
#    print "animaPlano"
    ## plano es un SoSwitch
    mat = searchByNodeType(plano, SoMaterial)
    ## ============================
    counter = SoOneShot()
    counter.duration = 0.4
    counter.trigger.touch()
    counter.flags = SoOneShot.HOLD_FINAL
    ## ============================
    calc = SoCalculator()
    calc.a.connectFrom(counter.ramp)
    ## la transparencia va de 1 a 0.4
    calc.expression.set1Value(0, "oa=1-a*0.7")
    ## ============================
    mat.transparency.connectFrom(calc.oa)
        
if __name__ == "__main__":
    app = main(sys.argv)
    window = Simetrias3Dplanos(None)
    window.resize(400,400)
    window.show()
    window.ui.show()
    SoQt.mainLoop()

