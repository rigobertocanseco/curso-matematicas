#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from pivy.gui.soqt import *
from pivy.coin import *
from PyQt4 import QtGui, QtCore, uic
from modulos.util import main, leeArchivo,  lee, conectaParcial
from math import sqrt, cos, sin, asin, pi, pow, cosh, tanh
from Visor import Visor
from Parametro import Motor
from PuntoReflejado import PuntoReflejado,  creaPunto,  Simetria
from util import Segmento, conecta,  busca,  norma, dictRepr, pjoin
import logging

log = logging.getLogger("Simetrias3D")
log.setLevel(logging.DEBUG)

def tval(vec):
    return vec.translation.getValue().getValue()


ptosIniciales = [
    (0.23092931509017944, -0.97293269634246826, 0.008585028350353241),
    (0.062104061245918274, -0.99541735649108887, 0.072714105248451233),
    (0.0078874900937080383, -0.99996376037597656, -0.0032022148370742798),
    (0.14072878658771515, -0.96030157804489136, 0.24086576700210571),
    (-0.066982358694076538, -0.99524295330047607, -0.070745386183261871),
    (-0.079387754201889038, -0.96970099210739136, 0.23103615641593933),
    (0.095697894692420959, -0.98286700248718262, 0.15752585232257843),
    (0.013792172074317932, -0.97998529672622681, 0.19859151542186737),
    (0.17384602129459381, -0.98077166080474854, 0.088681131601333618),
    (0.2572169303894043, -0.96314752101898193, -0.078652620315551758),
]

texto = [
    u"Elegimos una esfera para ilustrar los distintos tipos de simetría en el espacio.", 
    u"Una figura es simétrica respecto a un punto O si cada punto P de la figura tiene a su simétrico P’ respecto a O, también en la figura, donde O es el punto medio del segmento PP’. O se llama centro de simetría de la figura.", 
    u"Una figura es simétrica respecto a una recta L si cada punto P en la figura tiene a su simétrico P’ respecto a L también en la figura, donde la recta L es perpendicular al segmento PP’ por su punto medio. L se llama eje de simetría de la figura.", 
    u"Una figura es simétrica respecto a un plano M si cada punto P de la figura tiene a su simétrico P’ respecto del plano M también en la figura. El plano M es perpendicular al segmento PP’ en su punto medio y se llama plano de simetría de la figura."
]


class Simetrias3D(object):
    name = u"Simetrías en el espacio"
    def __init__(self,viewer=None,controles=None):
#        Visor.__init__(self,parent,controles,noestiloIni=True)
        ## contiene la esfera, el cilindro, etc
        self.objetosSimetria = []
        self.puntos = dictRepr()
        ## simetria puntual
        self.pages = []
        self.root = SoSeparator()
        self.simetria = Simetria()
        self.parent = self.viewer = viewer
        ## esto inserta la geometria de self.simetria *antes*
        ## de las paginas
        self.root.addChild(self.simetria)
        ## =========================
        self.cola1 = []
        self.cola2 = []
        ## =========================
        ## esfera
        mat = SoMaterial()
        mat.specularColor.setValue(.1, .1, .1)
        mat.transparency = 0.3
        com = SoComplexity()
        com.value = 1
        esfera = SoSphere()
        sep = SoSeparator()
        sep.addChild(mat)
        sep.addChild(com)
        sep.addChild(esfera)
        self.root.addChild(sep)
        self.objetoActual = 0
        self.objetosSimetria.append(esfera)
        ## ============================
        self.setupPoints()
        ## ============================
        self.setupGui()
#        conecta(self.viewer, QtCore.SIGNAL("simetriaCambiada"), self.setText)
        self.text = u"""\
Elegimos una esfera para ilustrar los distintos tipos de simetría en el espacio.\
<ul>
<li>Una figura es <b>simétrica respecto a un punto O</b> si cada punto P de la figura\
 tiene a su simétrico P’ respecto a O, también en la figura, donde O es el punto\
 medio del segmento PP’. O se llama <b>centro de simetría</b> de la figura.
 
<li>es <b>simétrica respecto a una recta L</b> si cada punto P en la figura tiene\
 a su simétrico P’ respecto a L también en la figura, donde la recta L es perpendicular\
 al segmento PP’ por su punto medio. L se llama <b>eje de simetría</b> de la figura.
 
<li>Una figura es <b>simétrica respecto a un plano M</b> si cada punto P de la figura tiene a\
 su simétrico P’ respecto del plano M también en la figura. El plano M es perpendicular\
 al segmento PP’ en su punto medio y se llama <b>plano de simetría</b> de la figura.
 </ul>
"""

#    def getProlog(self):
#        tt = SoTransparencyType()
#        tt.value = SoTransparencyType.SORTED_LAYERS_BLEND
#        tt.value = SoTransparencyType.ADD
#        return tt

    def getPages(self):
        return [self]

#    def setText(self, i):
#        print i
#        self.text = texto[0]+texto[i+1]
    
    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_NONE
        self.parent.lucesBlanca.on = True
        self.parent.viewer.setTransparencyType(SoGLRenderAction.SORTED_LAYERS_BLEND)
        self.parent.setDrawStyle(SoQtViewer.VIEW_AS_IS)

    def getGui(self):
        return self.gui

    def setupGui(self):
        ## creamos el ComboBox en el objecto actual (Visor)
        ## asi utilizamos connectSlotsByName
        self.gui = uic.loadUi(pjoin("modulos", "ui",  "tipos-simetrias.ui"))
        simetrias = [self.gui.simetriaPuntual, self.gui.simetriaAxial, self.gui.simetriaPlana]
        for i, rb in enumerate(simetrias):
            conectaParcial(rb, "clicked(bool)", self.on_tipoSimetria_Changed, i)

    def on_tipoSimetria_Changed(self, index, val):
        self.simetria.setTipo(index)
        self.viewer.emit(QtCore.SIGNAL('simetriaCambiada'), index)

    def setupPoints(self):
        "agregamos unos puntos iniciales"
#        ptos = [(.1,-1,.1), (-.1,-1,-.1), (-.1,-1,.1), (.1,-1,-.1)]
        for p in ptosIniciales:
            vec = SbVec3f(p)
            vec.normalize()
            self.agregaPunto(vec)

    def agregaPunto(self, coords):
        ## agregamos un punto nuevo
        pto = PuntoReflejado(coords, self.simetria)
        conecta(self.viewer, QtCore.SIGNAL("simetriaCambiada"), pto.update)
        self.root.addChild(pto)
        self.puntos[pto.p1.esfera] = pto
        pto.start()

    def correAnimacion(self):
        delta = 0.5
        if self.t == 0:
            nx = uniform(-1,1) * delta
            ny = uniform(-1,1) * delta
            nz = uniform(-1,1) * delta
            self.__old =  tval(self.cola1[0])
            dist = sqrt(self.__old[0]**2+ self.__old[1]**2+self.__old[2]**2)+1
            self.__new = (
                (self.__old[0] + nx)/dist,
                (self.__old[1] + ny)/dist,
                (self.__old[2] + nz)/dist)
        tf = self.t/59.0
        new = self.__new
        old = self.__old
        ix = old[0] + tf*(new[0] - old[0])
        iy = old[1] + tf*(new[1] - old[1])
        iz = old[2] + tf*(new[2] - old[2])
        # =========================
        # el primer elemento
        self.cola1[0].translation = (ix,iy,iz)
        self.p1.translation = (ix,iy,iz)
        self.cola2[0].translation = (-ix,-iy,-iz)
        self.p2.translation = (-ix,-iy,-iz)
        # =========================
        self.t += 1
        if self.t == 60:
            self.t = 0
            #~ self.viewer.viewAll()

if __name__ == "__main__":
    app = main(sys.argv)
    window = Simetrias3D()
    window.resize(700,700)
    window.rotor.on = False
    window.show()
    window.ui.show()
    SoQt.mainLoop()
