#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from pivy.gui.soqt import SoQt,  SoQtViewer
from pivy.coin import *
from PyQt4 import QtGui, QtCore, uic
from modulos.util import main, leeArchivo,  conectaParcial,  resta, searchByNodeType, OneShot, searchByName, getVol, pjoin, viewVolume
from math import sqrt, cos, sin, asin, pi, pow, cosh, tanh
from Visor import Visor
from Poliedro import Poliedro1 as Poliedro,  tubo,  esfera

def moduloPath(name):
    return pjoin("modulos","Platonicos",name)

ejesTetra = [
    ((0, 0, -0.367423), (0, 0, 0.775672)),
    ((-0.34641, 0, 0.122474), (0.73131, 0, -0.258557)), 
    ((0.173205, -0.3, 0.122474), (-0.365655, 0.633333, -0.258557)), 
    ((0.173205, 0.3, 0.122474), (-0.365655, -0.633333, -0.258557))
]

def insertScale(root, val=1):
    scale = SoScale()
    scale.scaleFactor = (val, val, val)
    root.insertChild(scale, 0)

class Platonicos(object):
    name = u"Sólidos Platónicos"
    def __init__(self,parent=None,uilayout=None):
        self.parent = parent
        self.viewAlloriginal = self.parent.viewer.viewAll
        ## ============================
        self.objetos = []
        self.agregaTetrahedro()
        self.agregaCubo()
        self.agregaOctaedro()
        self.agregaDodecaedro()
        self.agregaIcosaedro()
    
    def getPages(self):
        return self.objetos

    def chapterSpecific(self):
        self.parent.lucesColor.whichChild = SO_SWITCH_NONE
        self.parent.lucesBlanca.on = True
        self.parent.viewer.setTransparencyType(SoGLRenderAction.SORTED_LAYERS_BLEND)
        self.parent.setDrawStyle(SoQtViewer.VIEW_AS_IS)
        self.parent.viewer.viewAll = lambda:1
        viewVolume(self.parent.viewer, 1)
#        cubo = SoCube()
#        cubo.width = 1
#        cubo.height = 1
#        cubo.depth = 1
#        camera = self.parent.viewer.getCamera()
#        camera.viewAll(cubo, self.parent.viewer.getViewportRegion())
    
    def chapterSpecificOut(self):
        self.parent.viewer.viewAll = self.viewAlloriginal
        
    def agregaTetrahedro(self):
        datos = (4, 6, 4, moduloPath("tetraedro_plano.svg"))
        ob1 = Poliedro(leeArchivo(moduloPath("tetraedro.iv")),
            "tetraedro", datos=datos)
        ob1.text = u"El <b>tetraedro</b> tiene la característica de que cualquier par de vértices distan lo mismo: la longitud de una arista. Tiene 4 caras, 6 aristas y 4 vértices donde las caras concurren por tercias. Como vimos antes, el tetraedro admite 8 rotaciones en torno a la recta por un vértice y el ortocentro de la cara opuesta (para cada eje, se rota por 120° o por 240°) y 3 rotaciones de 180° en torno a la recta que pasa por puntos medios de aristas opuestas; admite también 6 planos de simetría determinados por una arista y el punto medio de la arista opuesta (lo cual intercambia sólo dos vértices), y otras 6 isometrías que invierten la orientación si primero rotamos y luego reflejamos en un plano de simetría. Si añadimos la identidad tenemos 24 isometrías, correspondientes a los elementos de permutaciones de 4 elementos que podemos ver como los vértices (buscar <b>grupo simétrico</b>)."
        self.objetos.append(ob1)
    
    def agregaCubo(self):
        datos = (6, 12, 8, moduloPath("cubo_plano.svg"))
        ob = Poliedro(leeArchivo(moduloPath("cubo.iv")),nombre="cubo",datos=datos)
        tc = Poliedro(leeArchivo(moduloPath("tetraedro-cubo.iv")), "", 1, 0, 0)
        tc.material.diffuseColor.setValue(1, .8, 0)
        tc.material.emissiveColor.setValue(.2, .1, 0)
        tc.material.transparency.setValue(0)
        
        switch = SoSwitch()
        switch.addChild(tc.root)
        ob.root.addChild(switch)
        ## ============================
        insertScale(ob.root, .8)
        ob.text = u"El <b>cubo</b> tiene 6 caras, 12 aristas y 8 vértices donde las caras concurren por ternas. Hay tres tipos de distancias entre vértices: la longitud de una arista, la de las diagonales de las caras, y la distancia entre dos vértices opuestos que definen una <b>diagonal mayor</b> (hay 4 de ellas). Una isometría que fije el cubo debe conservar las distancias entre los vértices y por eso llevará una diagonal mayor en otra. Las rotaciones que dejan invariante un cubo son: 3 rotaciones en torno a cada línea que pasa por los centros de caras opuestas: por 90°, 180° o 270°, lo cual da 9 rotaciones de este tipo; 6 rotaciones por 180° en torno a rectas por puntos medios de aristas opuestas; y rotaciones por 120° o por 240° en torno a una diagonal mayor. Las 4 diagonales mayores del cubo dan entonces 8 de estas rotaciones, y sumadas a las 15 anteriores dan 23 rotaciones diferentes que, con la identidad, dan 24 rotaciones distintas. Una de ellas seguida de la reflexión en un plano de simetría, por ejemplo un plano equidistante de 2 caras paralelas, dan otras 24 isometrías que fijan el cubo para un total de 48, el doble de los elementos del grupo de isometrías del tetraedro."
        self.objetos.append(ob)
        ## ============================
        cb = QtGui.QCheckBox(u"tetraedro inscrito")
        ob.layout().addWidget(cb)
        ob.layout().addStretch(1)
        ob.shot1 = OneShot(.3)
        ob.shot2 = OneShot(.3)
        conectaParcial(cb,"stateChanged(int)", lambda n: ob.shot1.start() if n == 2 else ob.shot2.start())
        ## la transparencia debe moverse del valor actual a 0.9
        val = ob.transparency.getValues()[0]
        ## de "ida" primero aparece el tetraedro y luego se desvancece el cubo
        conectaParcial(cb,"stateChanged(int)", lambda n: switch.whichChild.setValue(0) if n == 2 else None)
        conectaParcial(ob.shot1, "ramp(float)", lambda f: ob.transparency.setValue((1-val)*f + val))
        ## de "regreso" es al revés
        conectaParcial(ob.shot2, "ramp(float)", lambda f: ob.transparency.setValue((val-1)*f + 1))
        conectaParcial(ob.shot2, "finished(bool)", lambda b: switch.whichChild.setValue(-1))
        
        
    def agregaOctaedro(self):
        datos = (8, 12, 6, moduloPath("octaedro_plano.svg"))
        ob = Poliedro(leeArchivo(moduloPath("octaedro.iv")),
            nombre="octaedro",datos=datos)
        ob.text = u"El <b>octaedro</b> es el sólido platónico <b>dual</b> del cubo, es decir, los centros de las caras de un cubo son vértices de un octaedro regular; tiene 8 caras, 12 aristas y 6 vértices en los cuales concurren por ternas; por eso cualquier isometría del cubo es también una isometría del octaedro, y recíprocamente."
        self.objetos.append(ob)
        
    def agregaDodecaedro(self):
        datos = (12, 30, 20, moduloPath("dodecaedro_plano.svg"))
        ob = Poliedro(leeArchivo(moduloPath("dodecaedro.iv")),
            nombre="dodecaedro",datos=datos)
        insertScale(ob.root, .4)
        ob.text = u"Las caras del <b>dodecaedro</b> son 12, sus aristas son 30 y sus vértices son 20; en ellos las caras concurren por ternas. Los centros de rotación de las caras son los vértices de un <b>icosaedro</b>, por eso el dodecaedro y el icosaedro son sólidos platónicos duales uno de otro. El dodecaedro admite rotaciones por 72º (o por 144º o 216º o 288º) en torno a rectas que pasen por centros de rotación de caras opuestas (6 pares de caras opuestas dan 24 de estas rotaciones); también es posible rotar por 120º y por 240º en torno a la recta que pasa por vértices opuestos (10 pares de vértices opuestos dan 20 de estas rotaciones), y el último tipo posible de rotación es por 180º en torno a la recta por los puntos medios de aristas opuestas (15 pares de aristas opuestas dan 15 de estas rotaciones). Si a estas 59 rotaciones les sumamos la identidad tenemos 60 rotaciones en total, y al componerlas con la reflexión en un plano de simetría, por ejemplo el que contiene dos aristas opuestas, obtenemos un total de 120 isometrías para el dodecaedro, o para su dual, el icosaedro. <br> En un dodecaedro hay 5 cubos inscritos, mostramos sólo uno de ellos. Para formarlo,  elegimos en cada cara una diagonal así: en una cara elegimos una de sus cinco diagonales; esa diagonal es paralela a una de las aristas del dodecaedro, y esa arista es lado de otra cara pentagonal. En esta otra cara tomamos la diagonal paralela a la arista común, y en las  dos caras que tienen como vértice un extremo de la arista, tomamos diagonales que formen un cuadrado con las dos diagonales ya elegidas. El proceso se sigue hasta completar un cubo."
        self.objetos.append(ob)
        ## ============================
        dual = Poliedro(leeArchivo(moduloPath("icosaedro-dodecaedro.iv")), "", 1, 0, 0)
        dual.material.diffuseColor.setValue(0, .5, 0)
        dual.material.transparency.setValue(0)
        switch1 = SoSwitch()
        coords = searchByNodeType(dual.root, SoCoordinate3)
        switch1.addChild(dual.root)
        for p in coords.point:
            dual.root.addChild(esfera(p.getValue(), .02))
        ob.root.addChild(switch1)
        ## ============================
        cb1 = QtGui.QCheckBox(u"dual")
#        cb1.setStyleSheet("QWidget { background:yellow }")
        ob.layout().addWidget(cb1)
        ## ============================
        cubo = Poliedro(leeArchivo(moduloPath("cubo-dodecaedro.iv")), "", 1, 0, 0)
        cubo.material.diffuseColor.setValue(1, .8, 0)
        cubo.material.emissiveColor.setValue(.2, .1, 0)
        cubo.material.transparency.setValue(0)
        switch2 = SoSwitch()
        switch2.addChild(cubo.root)
        ob.root.addChild(switch2)
        ## ============================
        cb2 = QtGui.QCheckBox(u"cubo")
        ob.layout().addWidget(cb2)
        ob.layout().addStretch(1)
        ## ============================
        ## {0,1,2}
        ob.estado = 0
        ## ============================
        ob.shot1 = OneShot(.3)
        ob.shot2 = OneShot(.3)
        ## ============================
        def maneja(switch, n):
            if n == 2:
                if ob.estado == 0:
                    ob.shot1.start()
                ob.estado += 1
            elif n == 0:
                if ob.estado == 1:
                    ob.shot2.start()
                else:
                    switch.whichChild.setValue(-1)
                ob.estado -= 1
        ## ============================                
        conectaParcial(cb1,"stateChanged(int)", maneja, switch1)
        conectaParcial(cb2,"stateChanged(int)", maneja, switch2)
        conectaParcial(cb1,"stateChanged(int)", lambda n: switch1.whichChild.setValue(0) if n == 2 else None)
        conectaParcial(cb2,"stateChanged(int)", lambda n: switch2.whichChild.setValue(0) if n == 2 else None)
        ## ============================
        ## la transparencia debe moverse del valor actual a 0.9
        val = ob.transparency.getValues()[0]
        conectaParcial(ob.shot1, "ramp(float)", lambda f: ob.transparency.setValue((1-val)*f + val))
        conectaParcial(ob.shot2, "ramp(float)", lambda f: ob.transparency.setValue((val-1)*f + 1))
        ## ============================
        conectaParcial(ob.shot2, "finished(bool)", lambda b: switch1.whichChild.setValue(-1))
        conectaParcial(ob.shot2, "finished(bool)", lambda b: switch2.whichChild.setValue(-1))
        
        
    def agregaIcosaedro(self):
        datos = (20, 30, 12, moduloPath("icosaedro_plano.svg"))
        ob = Poliedro(leeArchivo(moduloPath("icosaedro.iv")),
            nombre="icosaedro",datos=datos)
        ob.text = u"En un <b>icosaedro</b> hay 20 caras, 30 aristas y 12 vértices donde las caras concurren por quintetas. Las isometrías del icosaedro se corresponden con las del dodecaedro por ser su dual."
        insertScale(ob.root, .6)
        self.objetos.append(ob)

def showChild0(switch, n):
    if n == 0:
        switch.whichChild = -1
    elif n == 2:
        switch.whichChild = 0

def rotaTetra(rot, normal, checked=False):
    ## el ángulo de rotación no puede ser 0.0
    rot.rotation.setValue(SbVec3f(*normal), 0.000000000001)
    ## ============================
    counter = SoOneShot()
    counter.duration = 1.0
    counter.trigger.touch()
#    counter.flags = SoOneShot.HOLD_FINAL
    ## ============================
    calc = SoCalculator()
    calc.a.connectFrom(counter.ramp)
    calc.expression.set1Value(0, "oa=a*2.0944")
    ## ============================
    crot = SoComposeRotation()
    eje = rot.rotation.getValue().getValue()[:3]
    crot.axis.setValue(eje)
    crot.angle.connectFrom(calc.oa)
    ## ============================
    rot.rotation.connectFrom(crot.rotation)


if __name__ == "__main__":
    app = main(sys.argv)
    window = Platonicos()
    window.resize(500, 500)
    window.rotor.on = False
    window.show()
    window.ui.show()
    SoQt.mainLoop()
